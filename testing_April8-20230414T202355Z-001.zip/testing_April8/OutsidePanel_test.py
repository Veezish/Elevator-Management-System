from OutsidePanel import OutsidePanel

    
def test_requestDown():
    a = OutsidePanel()
    a.button = "down"
    assert a.requestDown() == None
    
def test_requestUp():
    a = OutsidePanel()
    a.button = "up"
    assert a.requestUp() == None
    
if __name__ == "__main__":
    test_requestDown()
    test_requestUp
    print("Done")