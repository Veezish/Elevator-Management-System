from ElevatorControl import ElevatorControl
from InsidePanel import InsidePanel

def test_manageFloorRequestsUp():
    i = InsidePanel()
    i.pressButton(5)
    i.pressButton(4)
    i.pressButton(3)
    a = ElevatorControl(i)
    a.manageFloorRequestsUp()
    assert i.getFloorRequestList() == [3,4,5]

def test_manageFloorRequestsDown():
    i = InsidePanel()
    i.pressButton(5)
    i.pressButton(4)
    i.pressButton(3)
    a = ElevatorControl(i)
    a.manageFloorRequestsDown()
    assert i.getFloorRequestList() == [5,4,3]


if __name__ == "__main__":
    test_manageFloorRequestsUp()
    test_manageFloorRequestsDown()