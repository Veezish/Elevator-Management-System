from ElevatorControl import ElevatorControl
from Door import Door
from Elevator import Elevator
from OutsidePanel import OutsidePanel
from InsidePanel import InsidePanel
from main import UserInterface



def test_userInterface():
    assert UserInterface() 









if __name__ == "__main__":
    test_userInterface()