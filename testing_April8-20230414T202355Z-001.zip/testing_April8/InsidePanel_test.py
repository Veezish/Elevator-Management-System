from InsidePanel import InsidePanel

    

def test_getFloorRequestList():
    a = InsidePanel()
    a.requestList = [1,2]
    assert a.getFloorRequestList() == [1,2]
    
def test_clearFloorRequestList():
    a = InsidePanel()
    a.requestList = [3,4]
    assert a.clearFloorRequestList() == None
   

if __name__ == "__main__":
    test_getFloorRequestList()
    test_clearFloorRequestList()