from Door import Door

    
    
def test_close_door():
    door = Door()
    door.openDoor()
    door.closeDoor()
    assert door.getDoorStatus() == False

def test_set_door_status():
    door = Door()
    door.setDoorStatus(True)
    assert door.getDoorStatus() == True


if __name__ == "__main__":
    test_close_door()
    test_set_door_status()