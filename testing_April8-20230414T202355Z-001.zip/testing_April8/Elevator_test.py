from Elevator import Elevator


def test_initialization():
    a = Elevator
    a.currentFloor = 1
    a.destinationFloor = 5
    assert a.currentFloor == 1
    assert a.destinationFloor == 5
    
def test_move():
    a = Elevator(101, 1)
    a.move(4)
    assert a.getCurrentFloor() == 4

if __name__ == "__main__":
    test_initialization()
    test_move()